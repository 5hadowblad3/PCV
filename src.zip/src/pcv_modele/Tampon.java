package pcv_modele;

public class Tampon 
{
	private int Nb;
	
	public Tampon()
	{
		this.Nb=0;
	}
	
	public int getNb() 
	{
		return Nb;
	}

	public void setNb(int Nb) 
	{
		this.Nb=Nb;
	}
}